import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import 'package:pgc_app/models/booking.dart';
import 'package:pgc_app/providers/auth_provider.dart';
import 'package:pgc_app/theme/app_theme.dart';
import 'package:pgc_app/widgets/pgc_avatar.dart';

class MyBookingsScreen extends StatefulWidget {
  const MyBookingsScreen({super.key});

  @override
  State<MyBookingsScreen> createState() => _MyBookingsScreenState();
}

class _MyBookingsScreenState extends State<MyBookingsScreen> {
  List<Booking> _bookings = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadBookings();
  }

  Future<void> _loadBookings() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final bookings = await context.read<AuthProvider>().api.getMyBookings();
      setState(() {
        _bookings = bookings;
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _error = e.toString();
        _loading = false;
      });
    }
  }

  Future<void> _cancel(int bookingId) async {
    try {
      await context.read<AuthProvider>().api.cancelBooking(bookingId);
      await _loadBookings();
    } catch (e) {
      setState(() => _error = e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(title: const Text('Mes cours')),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: AppColors.gold))
          : _error != null
              ? Center(child: Text(_error!, style: const TextStyle(color: AppColors.danger)))
              : _bookings.isEmpty
                  ? const Center(child: Text('Aucune réservation', style: TextStyle(color: AppColors.muted)))
                  : RefreshIndicator(
                      onRefresh: _loadBookings,
                      child: ListView.builder(
                        padding: const EdgeInsets.fromLTRB(16, 16, 16, 110),
                        itemCount: _bookings.length,
                        itemBuilder: (_, i) => _BookingCard(
                          booking: _bookings[i],
                          onCancel: () => _cancel(_bookings[i].id),
                        ),
                      ),
                    ),
    );
  }
}

class _BookingCard extends StatelessWidget {
  final Booking booking;
  final VoidCallback onCancel;
  const _BookingCard({required this.booking, required this.onCancel});

  @override
  Widget build(BuildContext context) {
    final course = booking.course;
    final start = course?.startTime;

    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: GestureDetector(
                  onTap: course == null ? null : () => context.go('/courses/${course.id}'),
                  child: Text(
                    course?.name ?? 'Cours #${booking.courseId}',
                    style: const TextStyle(color: AppColors.text, fontSize: 17, fontWeight: FontWeight.w900),
                  ),
                ),
              ),
              Text(booking.statusLabel, style: const TextStyle(color: AppColors.gold, fontSize: 12, fontWeight: FontWeight.w800)),
            ],
          ),
          if (start != null) ...[
            const SizedBox(height: 8),
            Text(DateFormat('EEE d MMM · HH:mm', 'fr_FR').format(start), style: const TextStyle(color: AppColors.muted)),
          ],
          if (course?.coachId != null) ...[
            const SizedBox(height: 14),
            GestureDetector(
              onTap: () => context.go('/coaches/${course!.coachId}'),
              child: Row(
                children: [
                  PgcAvatar(avatarUrl: course!.coachAvatarUrl, initials: course.coachInitials, radius: 18),
                  const SizedBox(width: 10),
                  Text(course.coachFullName, style: const TextStyle(color: AppColors.text, fontWeight: FontWeight.w800)),
                  const SizedBox(width: 4),
                  const Icon(Icons.chevron_right, color: AppColors.gold, size: 18),
                ],
              ),
            ),
          ],
          if (!booking.isCancelled) ...[
            const SizedBox(height: 12),
            Align(
              alignment: Alignment.centerRight,
              child: TextButton.icon(
                onPressed: onCancel,
                icon: const Icon(Icons.cancel, color: AppColors.danger),
                label: const Text('Annuler', style: TextStyle(color: AppColors.danger)),
              ),
            ),
          ],
        ],
      ),
    );
  }
}
