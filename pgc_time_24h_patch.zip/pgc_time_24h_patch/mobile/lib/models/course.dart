import 'package:pgc_app/models/member.dart';
import 'package:pgc_app/utils/local_date_time.dart';

class Course {
  final int id;
  final String name;
  final String? description;
  final String courseType;
  final String level;
  final DateTime startTime;
  final DateTime endTime;
  final int maxCapacity;
  final int? coachId;
  final Member? coach;

  // Compatibilité avec les versions précédentes de l'API qui retournaient
  // les infos coach à plat.
  final String? coachFirstName;
  final String? coachLastName;
  final String? coachAvatarUrl;

  final int? spotsAvailable;
  final DateTime createdAt;

  Course({
    required this.id,
    required this.name,
    this.description,
    required this.courseType,
    required this.level,
    required this.startTime,
    required this.endTime,
    required this.maxCapacity,
    this.coachId,
    this.coach,
    this.coachFirstName,
    this.coachLastName,
    this.coachAvatarUrl,
    this.spotsAvailable,
    required this.createdAt,
  });

  factory Course.fromJson(Map<String, dynamic> json) {
    final coachJson = json['coach'];
    final parsedCoach = coachJson is Map<String, dynamic>
        ? Member.fromJson(coachJson)
        : null;

    return Course(
      id: json['id'],
      name: json['name'],
      description: json['description'],
      courseType: json['course_type'],
      level: json['level'],
      startTime: LocalDateTime.parseApiString(json['start_time']),
      endTime: LocalDateTime.parseApiString(json['end_time']),
      maxCapacity: json['max_capacity'],
      coachId: json['coach_id'] ?? parsedCoach?.id,
      coach: parsedCoach,
      coachFirstName: json['coach_first_name'] ?? parsedCoach?.firstName,
      coachLastName: json['coach_last_name'] ?? parsedCoach?.lastName,
      coachAvatarUrl: json['coach_avatar_url'] ?? parsedCoach?.avatarUrl,
      spotsAvailable: json['spots_available'],
      createdAt: LocalDateTime.parseApiString(json['created_at']),
    );
  }

  bool get isFull => spotsAvailable != null && spotsAvailable! == 0;
  bool get hasStarted => DateTime.now().isAfter(startTime);
  bool get isPast => DateTime.now().isAfter(endTime);

  String get coachFullName {
    final first = (coach?.firstName ?? coachFirstName ?? '').trim();
    final last = (coach?.lastName ?? coachLastName ?? '').trim();
    final full = '$first $last'.trim();
    return full.isEmpty ? 'Coach à assigner' : full;
  }

  String get coachInitials {
    final first = (coach?.firstName ?? coachFirstName ?? '').trim();
    final last = (coach?.lastName ?? coachLastName ?? '').trim();
    final initials = '${first.isNotEmpty ? first[0] : ''}${last.isNotEmpty ? last[0] : ''}';
    return initials.isEmpty ? 'PGC' : initials;
  }

  String? get effectiveCoachAvatarUrl => coach?.avatarUrl ?? coachAvatarUrl;

  String get courseTypeLabel {
    const labels = {
      'grappling': 'NoGi Grappling',
      'bjj': 'BJJ',
      'mma': 'MMA',
      'wrestling': 'Wrestling',
      'boxing': 'Boxing',
      'kickboxing': 'Kickboxing',
      'muay_thai': 'Muay Thai',
      'other': 'Autre',
    };
    return labels[courseType] ?? courseType;
  }

  String get levelLabel {
    const labels = {
      'beginner': 'Débutant',
      'intermediate': 'Intermédiaire',
      'advanced': 'Avancé',
      'all_levels': 'Tous niveaux',
    };
    return labels[level] ?? level;
  }
}
