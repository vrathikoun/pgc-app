import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import 'package:pgc_app/models/booking.dart';
import 'package:pgc_app/models/course.dart';
import 'package:pgc_app/models/member.dart';
import 'package:pgc_app/providers/auth_provider.dart';
import 'package:pgc_app/services/api_service.dart';
import 'package:pgc_app/theme/app_theme.dart';

class CourseDetailScreen extends StatefulWidget {
  final int courseId;
  const CourseDetailScreen({super.key, required this.courseId});

  @override
  State<CourseDetailScreen> createState() => _CourseDetailScreenState();
}

class _CourseDetailScreenState extends State<CourseDetailScreen> {
  Course? _course;
  List<Booking> _bookings = [];
  bool _loading = true;
  bool _booking = false;
  String? _error;
  String? _successMessage;

  @override
  void initState() {
    super.initState();
    _loadCourse();
  }

  Future<void> _loadCourse() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    final auth = context.read<AuthProvider>();
    final api = auth.api;
    try {
      final course = await api.getCourse(widget.courseId);
      var bookings = <Booking>[];
      final member = auth.member;
      final canSeeBookings = member?.isAdmin == true ||
          (member?.isCoach == true && course.coachId == member?.id);
      if (canSeeBookings) {
        bookings = await api.getCourseBookings(widget.courseId);
      }
      setState(() {
        _course = course;
        _bookings = bookings;
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _error = e.toString();
        _loading = false;
      });
    }
  }

  Future<void> _book() async {
    setState(() {
      _booking = true;
      _error = null;
      _successMessage = null;
    });

    try {
      final booking = await context.read<AuthProvider>().api.createBooking(widget.courseId);
      setState(() {
        _successMessage = booking.isWaitlist
            ? 'Cours complet — tu es en liste d’attente ⏳'
            : 'Réservation confirmée ✅';
      });
      await _loadCourse();
    } on ApiException catch (e) {
      setState(() => _error = e.message);
    } catch (e) {
      setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _booking = false);
    }
  }

  ImageProvider? _avatarProvider(BuildContext context, String? rawUrl) {
    final url = rawUrl?.trim();
    if (url == null || url.isEmpty) return null;
    if (url.startsWith('assets/')) return AssetImage(url);
    if (url.startsWith('http')) return NetworkImage(url);
    final base = context.read<AuthProvider>().api.baseUrl.replaceAll(RegExp(r'/$'), '');
    return NetworkImage('$base$url');
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final canAdminEdit = auth.member?.isAdmin ?? false;

    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.go('/courses'),
        ),
        title: const Text('Détail du cours'),
        actions: [
          if (canAdminEdit && _course != null)
            IconButton(
              icon: const Icon(Icons.edit, color: AppColors.gold),
              onPressed: () => context.go('/admin/courses/${_course!.id}/edit'),
            ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: AppColors.gold))
          : _course == null
              ? const Center(child: Text('Cours introuvable', style: TextStyle(color: AppColors.muted)))
              : _buildContent(context),
    );
  }

  Widget _buildContent(BuildContext context) {
    final course = _course!;
    final dateFormat = DateFormat('EEEE d MMMM yyyy', 'fr_FR');
    final timeFormat = DateFormat('HH:mm');
    final auth = context.watch<AuthProvider>();
    final current = auth.member;
    final canSeeBookings = current?.isAdmin == true ||
        (current?.isCoach == true && course.coachId == current?.id);

    return ListView(
      padding: const EdgeInsets.fromLTRB(24, 16, 24, 120),
      children: [
        Text(
          course.name,
          style: const TextStyle(color: AppColors.text, fontSize: 30, fontWeight: FontWeight.w900),
        ),
        const SizedBox(height: 8),
        Text(course.courseTypeLabel, style: const TextStyle(color: AppColors.gold, fontSize: 16, fontWeight: FontWeight.w700)),
        const SizedBox(height: 20),
        if (course.coach != null) _CoachMiniCard(coach: course.coach!, avatarProvider: _avatarProvider(context, course.coach!.avatarUrl)),
        const SizedBox(height: 22),
        _InfoCard(children: [
          _infoRow(Icons.calendar_today, dateFormat.format(course.startTime)),
          _sep(),
          _infoRow(Icons.access_time, '${timeFormat.format(course.startTime)} → ${timeFormat.format(course.endTime)}'),
          _sep(),
          _infoRow(Icons.signal_cellular_alt, course.levelLabel),
          _sep(),
          _infoRow(Icons.people, course.isFull ? 'Cours complet' : '${course.spotsAvailable} place(s) disponible(s)'),
        ]),
        if (course.description != null && course.description!.trim().isNotEmpty) ...[
          const SizedBox(height: 22),
          const Text('Description', style: TextStyle(color: AppColors.muted, fontSize: 13, fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          Text(course.description!, style: const TextStyle(color: Colors.white70, height: 1.4)),
        ],
        const SizedBox(height: 22),
        if (_successMessage != null) _MessageBox(text: _successMessage!, color: AppColors.green),
        if (_error != null) _MessageBox(text: _error!, color: AppColors.danger),
        const SizedBox(height: 16),
        if (!course.hasStarted)
          SizedBox(
            width: double.infinity,
            height: 52,
            child: ElevatedButton(
              onPressed: _booking ? null : _book,
              style: ElevatedButton.styleFrom(backgroundColor: AppColors.darkGreen, foregroundColor: Colors.white),
              child: _booking
                  ? const CircularProgressIndicator(color: Colors.white)
                  : Text(course.isFull ? 'Rejoindre la liste d’attente' : 'Réserver ce cours'),
            ),
          )
        else
          const _MessageBox(text: 'Le cours a commencé : les réservations et annulations sont fermées.', color: AppColors.muted),
        if (canSeeBookings) ...[
          const SizedBox(height: 28),
          const Text('Inscrits au cours', style: TextStyle(color: AppColors.text, fontSize: 20, fontWeight: FontWeight.w900)),
          const SizedBox(height: 12),
          if (_bookings.isEmpty)
            const Text('Aucun inscrit pour le moment.', style: TextStyle(color: AppColors.muted))
          else
            ..._bookings.map((b) => _BookingMemberTile(booking: b, avatarProvider: _avatarProvider(context, b.member?.avatarUrl))),
        ],
      ],
    );
  }

  Widget _infoRow(IconData icon, String text) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
        child: Row(children: [
          Icon(icon, color: AppColors.gold, size: 18),
          const SizedBox(width: 12),
          Expanded(child: Text(text, style: const TextStyle(color: Colors.white70, fontSize: 15))),
        ]),
      );

  Widget _sep() => const Divider(color: AppColors.border, height: 1, indent: 48);
}

class _CoachMiniCard extends StatelessWidget {
  final Member coach;
  final ImageProvider? avatarProvider;
  const _CoachMiniCard({required this.coach, required this.avatarProvider});

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(20), border: Border.all(color: AppColors.border)),
        child: Row(children: [
          CircleAvatar(
            radius: 24,
            backgroundColor: AppColors.surface2,
            backgroundImage: avatarProvider,
            child: avatarProvider == null ? Text(coach.firstName.characters.first, style: const TextStyle(color: AppColors.gold)) : null,
          ),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Coach', style: TextStyle(color: AppColors.muted, fontSize: 12)),
            Text(coach.fullName, style: const TextStyle(color: AppColors.text, fontSize: 16, fontWeight: FontWeight.w800)),
          ])),
        ]),
      );
}

class _BookingMemberTile extends StatelessWidget {
  final Booking booking;
  final ImageProvider? avatarProvider;
  const _BookingMemberTile({required this.booking, required this.avatarProvider});

  @override
  Widget build(BuildContext context) {
    final member = booking.member;
    if (member == null) return const SizedBox.shrink();
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(18), border: Border.all(color: AppColors.border)),
      child: Row(children: [
        CircleAvatar(radius: 22, backgroundColor: AppColors.surface2, backgroundImage: avatarProvider, child: avatarProvider == null ? Text(member.firstName.characters.first, style: const TextStyle(color: AppColors.gold)) : null),
        const SizedBox(width: 12),
        Expanded(child: Text(member.fullName, style: const TextStyle(color: AppColors.text, fontWeight: FontWeight.w800))),
        Text(booking.statusLabel, style: const TextStyle(color: AppColors.muted, fontSize: 12)),
      ]),
    );
  }
}

class _InfoCard extends StatelessWidget {
  final List<Widget> children;
  const _InfoCard({required this.children});
  @override
  Widget build(BuildContext context) => Container(
        decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(20), border: Border.all(color: AppColors.border)),
        child: Column(children: children),
      );
}

class _MessageBox extends StatelessWidget {
  final String text;
  final Color color;
  const _MessageBox({required this.text, required this.color});
  @override
  Widget build(BuildContext context) => Container(
        width: double.infinity,
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: color.withOpacity(0.14), borderRadius: BorderRadius.circular(14), border: Border.all(color: color.withOpacity(0.4))),
        child: Text(text, style: TextStyle(color: color, fontWeight: FontWeight.w700), textAlign: TextAlign.center),
      );
}
