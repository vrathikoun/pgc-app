import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import 'package:pgc_app/models/booking.dart';
import 'package:pgc_app/providers/auth_provider.dart';
import 'package:pgc_app/theme/app_theme.dart';

class MyBookingsScreen extends StatefulWidget {
  const MyBookingsScreen({super.key});

  @override
  State<MyBookingsScreen> createState() => _MyBookingsScreenState();
}

class _MyBookingsScreenState extends State<MyBookingsScreen> {
  List<Booking> _bookings = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadBookings();
  }

  Future<void> _loadBookings() async {
    setState(() { _loading = true; _error = null; });
    try {
      final bookings = await context.read<AuthProvider>().api.getMyBookings();
      setState(() { _bookings = bookings; _loading = false; });
    } catch (e) {
      setState(() { _error = e.toString(); _loading = false; });
    }
  }

  Future<void> _cancel(Booking booking) async {
    try {
      await context.read<AuthProvider>().api.cancelBooking(booking.id);
      await _loadBookings();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString()), backgroundColor: AppColors.danger));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final upcoming = _bookings.where((b) => b.course != null && !b.course!.isPast && !b.isCancelled).toList();
    final history = _bookings.where((b) => b.course == null || b.course!.isPast || b.isCancelled).toList();

    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(title: const Text('Mes cours')),
      body: RefreshIndicator(
        onRefresh: _loadBookings,
        child: _loading
            ? const Center(child: CircularProgressIndicator(color: AppColors.gold))
            : ListView(
                padding: const EdgeInsets.fromLTRB(18, 16, 18, 110),
                children: [
                  if (_error != null) Text(_error!, style: const TextStyle(color: AppColors.danger)),
                  const Text('À venir', style: TextStyle(color: AppColors.text, fontSize: 28, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 12),
                  if (upcoming.isEmpty) const _EmptyBox('Aucune réservation à venir.') else ...upcoming.map((b) => _BookingCard(booking: b, onCancel: b.canCancel ? () => _cancel(b) : null)),
                  const SizedBox(height: 28),
                  const Text('Historique', style: TextStyle(color: AppColors.text, fontSize: 24, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 12),
                  if (history.isEmpty) const _EmptyBox('Aucun cours dans l’historique.') else ...history.map((b) => _BookingCard(booking: b, onCancel: null)),
                ],
              ),
      ),
    );
  }
}

class _BookingCard extends StatelessWidget {
  final Booking booking;
  final VoidCallback? onCancel;
  const _BookingCard({required this.booking, this.onCancel});

  @override
  Widget build(BuildContext context) {
    final course = booking.course;
    final date = course != null ? DateFormat('EEE d MMM · HH:mm', 'fr_FR').format(course.startTime) : 'Cours #${booking.courseId}';
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(20), border: Border.all(color: AppColors.border)),
      child: Row(children: [
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(course?.name ?? 'Cours #${booking.courseId}', style: const TextStyle(color: AppColors.text, fontSize: 17, fontWeight: FontWeight.w800)),
          const SizedBox(height: 6),
          Text('$date · ${booking.statusLabel}', style: const TextStyle(color: AppColors.muted, fontSize: 13)),
          if (course?.hasStarted == true && !booking.isCancelled) const Padding(padding: EdgeInsets.only(top: 6), child: Text('Annulation fermée', style: TextStyle(color: AppColors.gold, fontSize: 12, fontWeight: FontWeight.w700))),
        ])),
        if (onCancel != null)
          IconButton(icon: const Icon(Icons.cancel, color: AppColors.danger), onPressed: onCancel),
      ]),
    );
  }
}

class _EmptyBox extends StatelessWidget {
  final String text;
  const _EmptyBox(this.text);
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(18), border: Border.all(color: AppColors.border)),
        child: Text(text, style: const TextStyle(color: AppColors.muted)),
      );
}
