import 'package:pgc_app/models/course.dart';
import 'package:pgc_app/models/member.dart';

class Booking {
  final int id;
  final int memberId;
  final int courseId;
  final String status;
  final String? notes;
  final DateTime bookedAt;
  final DateTime? cancelledAt;
  final Course? course;
  final Member? member;

  Booking({
    required this.id,
    required this.memberId,
    required this.courseId,
    required this.status,
    this.notes,
    required this.bookedAt,
    this.cancelledAt,
    this.course,
    this.member,
  });

  factory Booking.fromJson(Map<String, dynamic> json) => Booking(
        id: json['id'],
        memberId: json['member_id'],
        courseId: json['course_id'],
        status: json['status'],
        notes: json['notes'],
        bookedAt: DateTime.parse(json['booked_at']).toLocal(),
        cancelledAt: json['cancelled_at'] != null
            ? DateTime.parse(json['cancelled_at']).toLocal()
            : null,
        course: json['course'] != null ? Course.fromJson(json['course']) : null,
        member: json['member'] != null ? Member.fromJson(json['member']) : null,
      );

  bool get isConfirmed => status == 'confirmed';
  bool get isWaitlist => status == 'waitlist';
  bool get isCancelled => status == 'cancelled';
  bool get isAttended => status == 'attended';
  bool get isPast => course != null && DateTime.now().isAfter(course!.endTime);
  bool get canCancel => course != null && !isCancelled && DateTime.now().isBefore(course!.startTime);

  String get statusLabel {
    const labels = {
      'confirmed': 'Confirmé',
      'cancelled': 'Annulé',
      'waitlist': 'Liste d’attente',
      'attended': 'Présent',
    };
    return labels[status] ?? status;
  }
}
