from datetime import datetime, timedelta, timezone
from typing import List

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session, joinedload

from app.database import get_db
from app.models.booking import Booking, BookingStatus
from app.models.course import Course
from app.models.member import Member, MemberRole
from app.routers.members import get_current_member
from app.schemas.booking_schema import BookingCreate, BookingOut
from app.services import email_service

router = APIRouter(prefix="/bookings", tags=["Bookings"])


def _confirmed_count(course_id: int, db: Session) -> int:
    return (
        db.query(Booking)
        .filter(Booking.course_id == course_id, Booking.status == BookingStatus.confirmed)
        .count()
    )


def _now_utc() -> datetime:
    return datetime.now(timezone.utc)


def _as_aware(dt: datetime) -> datetime:
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt


def _week_bounds(dt: datetime) -> tuple[datetime, datetime]:
    d = _as_aware(dt)
    start = d - timedelta(days=d.weekday())
    start = start.replace(hour=0, minute=0, second=0, microsecond=0)
    end = start + timedelta(days=7)
    return start, end


@router.get("/me", response_model=List[BookingOut])
def my_bookings(
    current: Member = Depends(get_current_member),
    db: Session = Depends(get_db),
):
    return (
        db.query(Booking)
        .options(joinedload(Booking.course).joinedload(Course.coach))
        .filter(Booking.member_id == current.id)
        .join(Course)
        .order_by(Course.start_time.desc())
        .all()
    )


@router.post("/", response_model=BookingOut, status_code=201)
def create_booking(
    data: BookingCreate,
    current: Member = Depends(get_current_member),
    db: Session = Depends(get_db),
):
    course = db.query(Course).filter(Course.id == data.course_id).first()
    if not course:
        raise HTTPException(status_code=404, detail="Cours introuvable")

    if _as_aware(course.start_time) <= _now_utc():
        raise HTTPException(status_code=400, detail="Ce cours a déjà commencé")

    existing = (
        db.query(Booking)
        .filter(
            Booking.member_id == current.id,
            Booking.course_id == data.course_id,
            Booking.status.in_([BookingStatus.confirmed, BookingStatus.waitlist]),
        )
        .first()
    )
    if existing:
        raise HTTPException(status_code=400, detail="Vous êtes déjà inscrit à ce cours")

    weekly_limit = getattr(current, "weekly_booking_limit", None)
    if weekly_limit is not None and weekly_limit > 0:
        week_start, week_end = _week_bounds(course.start_time)
        weekly_count = (
            db.query(Booking)
            .join(Course)
            .filter(
                Booking.member_id == current.id,
                Booking.status == BookingStatus.confirmed,
                Course.start_time >= week_start,
                Course.start_time < week_end,
            )
            .count()
        )
        if weekly_count >= weekly_limit:
            raise HTTPException(
                status_code=400,
                detail=f"Limite atteinte : {weekly_limit} cours maximum par semaine",
            )

    count = _confirmed_count(data.course_id, db)
    status = BookingStatus.confirmed if count < course.max_capacity else BookingStatus.waitlist

    booking = Booking(member_id=current.id, course_id=data.course_id, status=status)
    db.add(booking)
    db.commit()
    db.refresh(booking)

    email_service.send_booking_confirmation(
        first_name=current.first_name,
        email=current.email,
        course_name=course.name,
        start_time=course.start_time.strftime("%d/%m/%Y à %H:%M"),
    )
    return booking


@router.delete("/{booking_id}", response_model=BookingOut)
def cancel_booking(
    booking_id: int,
    current: Member = Depends(get_current_member),
    db: Session = Depends(get_db),
):
    booking = (
        db.query(Booking)
        .options(joinedload(Booking.course))
        .filter(Booking.id == booking_id, Booking.member_id == current.id)
        .first()
    )
    if not booking:
        raise HTTPException(status_code=404, detail="Réservation introuvable")
    if booking.status == BookingStatus.cancelled:
        raise HTTPException(status_code=400, detail="Réservation déjà annulée")
    if _as_aware(booking.course.start_time) <= _now_utc():
        raise HTTPException(status_code=400, detail="Le cours a commencé : annulation impossible")

    booking.status = BookingStatus.cancelled
    booking.cancelled_at = _now_utc()
    db.commit()

    email_service.send_booking_cancellation(
        first_name=current.first_name,
        email=current.email,
        course_name=booking.course.name,
    )

    next_waiting = (
        db.query(Booking)
        .filter(Booking.course_id == booking.course_id, Booking.status == BookingStatus.waitlist)
        .order_by(Booking.booked_at)
        .first()
    )
    if next_waiting:
        next_waiting.status = BookingStatus.confirmed
        db.commit()
        promoted_member = db.query(Member).filter(Member.id == next_waiting.member_id).first()
        if promoted_member:
            email_service.send_waitlist_promoted(
                first_name=promoted_member.first_name,
                email=promoted_member.email,
                course_name=booking.course.name,
                start_time=booking.course.start_time.strftime("%d/%m/%Y à %H:%M"),
            )

    db.refresh(booking)
    return booking


@router.get("/course/{course_id}", response_model=List[BookingOut])
def course_bookings(
    course_id: int,
    current: Member = Depends(get_current_member),
    db: Session = Depends(get_db),
):
    course = db.query(Course).filter(Course.id == course_id).first()
    if not course:
        raise HTTPException(status_code=404, detail="Cours introuvable")

    is_admin = current.role == MemberRole.admin
    is_assigned_coach = current.role == MemberRole.coach and course.coach_id == current.id
    if not (is_admin or is_assigned_coach):
        raise HTTPException(status_code=403, detail="Réservé aux coachs assignés et admins")

    return (
        db.query(Booking)
        .options(joinedload(Booking.member), joinedload(Booking.course).joinedload(Course.coach))
        .filter(Booking.course_id == course_id)
        .order_by(Booking.booked_at)
        .all()
    )
