import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import 'package:pgc_app/models/member.dart';
import 'package:pgc_app/providers/auth_provider.dart';
import 'package:pgc_app/theme/app_theme.dart';
import 'package:pgc_app/widgets/pgc_section_header.dart';

class CourseFormScreen extends StatefulWidget {
  const CourseFormScreen({super.key});

  @override
  State<CourseFormScreen> createState() => _CourseFormScreenState();
}

class _CourseFormScreenState extends State<CourseFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameCtrl = TextEditingController(text: 'NoGi Fundamentals');
  final _descriptionCtrl = TextEditingController();
  final _capacityCtrl = TextEditingController(text: '20');

  String _courseType = 'grappling';
  String _level = 'all_levels';
  DateTime _date = DateTime.now().add(const Duration(days: 1));
  TimeOfDay _start = const TimeOfDay(hour: 19, minute: 00);
  TimeOfDay _end = const TimeOfDay(hour: 20, minute: 30);
  int? _coachId;
  List<Member> _coaches = [];
  bool _saving = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadCoaches();
  }

  Future<void> _loadCoaches() async {
    try {
      final members = await context.read<AuthProvider>().api.getMembers(limit: 200);
      setState(() => _coaches = members.where((m) => m.role == 'coach' || m.role == 'admin').toList());
    } catch (_) {}
  }

  DateTime _merge(DateTime date, TimeOfDay time) {
    return DateTime(date.year, date.month, date.day, time.hour, time.minute);
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: DateTime.now().subtract(const Duration(days: 1)),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );
    if (picked != null) setState(() => _date = picked);
  }

  Future<void> _pickTime({required bool start}) async {
    final picked = await showTimePicker(context: context, initialTime: start ? _start : _end);
    if (picked != null) setState(() => start ? _start = picked : _end = picked);
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() {
      _saving = true;
      _error = null;
    });

    try {
      await context.read<AuthProvider>().api.createCourse(
            name: _nameCtrl.text.trim(),
            description: _descriptionCtrl.text.trim().isEmpty ? null : _descriptionCtrl.text.trim(),
            courseType: _courseType,
            level: _level,
            startTime: _merge(_date, _start),
            endTime: _merge(_date, _end),
            maxCapacity: int.parse(_capacityCtrl.text),
            coachId: _coachId,
          );
      if (!mounted) return;
      context.go('/admin/schedule');
    } catch (e) {
      setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(title: const Text('Nouveau cours')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const PgcSectionHeader(
            eyebrow: 'Class builder',
            title: 'Créer un cours',
            subtitle: 'Construis ton planning comme des modules premium.',
          ),
          const SizedBox(height: 24),
          Form(
            key: _formKey,
            child: Column(
              children: [
                TextFormField(
                  controller: _nameCtrl,
                  decoration: const InputDecoration(labelText: 'Nom du cours'),
                  validator: (v) => v == null || v.trim().isEmpty ? 'Nom requis' : null,
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _descriptionCtrl,
                  maxLines: 3,
                  decoration: const InputDecoration(labelText: 'Description'),
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  value: _courseType,
                  decoration: const InputDecoration(labelText: 'Type'),
                  items: const [
                    DropdownMenuItem(value: 'grappling', child: Text('Grappling')),
                    DropdownMenuItem(value: 'wrestling', child: Text('Wrestling')),
                    DropdownMenuItem(value: 'mma', child: Text('MMA')),
                    DropdownMenuItem(value: 'other', child: Text('Autre')),
                  ],
                  onChanged: (v) => setState(() => _courseType = v!),
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  value: _level,
                  decoration: const InputDecoration(labelText: 'Niveau'),
                  items: const [
                    DropdownMenuItem(value: 'beginner', child: Text('Débutant')),
                    DropdownMenuItem(value: 'intermediate', child: Text('Intermédiaire')),
                    DropdownMenuItem(value: 'advanced', child: Text('Avancé')),
                    DropdownMenuItem(value: 'all_levels', child: Text('Tous niveaux')),
                  ],
                  onChanged: (v) => setState(() => _level = v!),
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<int?>(
                  value: _coachId,
                  decoration: const InputDecoration(labelText: 'Coach assigné'),
                  items: [
                    const DropdownMenuItem<int?>(value: null, child: Text('Aucun coach')),
                    ..._coaches.map((m) => DropdownMenuItem<int?>(value: m.id, child: Text(m.fullName))),
                  ],
                  onChanged: (v) => setState(() => _coachId = v),
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _capacityCtrl,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'Capacité maximale'),
                  validator: (v) {
                    final n = int.tryParse(v ?? '');
                    if (n == null || n <= 0) return 'Capacité invalide';
                    return null;
                  },
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: _pickDate,
                        icon: const Icon(Icons.calendar_today),
                        label: Text('${_date.day}/${_date.month}/${_date.year}'),
                      ),
                    ),
                  ],
                ),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () => _pickTime(start: true),
                        icon: const Icon(Icons.play_arrow),
                        label: Text(_start.format(context)),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () => _pickTime(start: false),
                        icon: const Icon(Icons.stop),
                        label: Text(_end.format(context)),
                      ),
                    ),
                  ],
                ),
                if (_error != null) ...[
                  const SizedBox(height: 12),
                  Text(_error!, style: const TextStyle(color: AppColors.danger)),
                ],
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: _saving ? null : _submit,
                  child: Text(_saving ? 'Création...' : 'Créer le cours'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
