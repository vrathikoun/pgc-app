# PGC admin + UI patch

Copie ces fichiers dans ton repo à la racine `pgc-app`.

## Option rapide

Depuis la racine de ton repo :

```bash
unzip pgc_admin_patch.zip -d /tmp/pgc_patch
cp -r /tmp/pgc_patch/mobile ./
cp -r /tmp/pgc_patch/app ./
```

Puis backend :

```bash
source .venv/bin/activate
python -m uvicorn app.main:app --reload
```

Puis frontend :

```bash
cd mobile
flutter clean
flutter pub get
flutter run -d chrome
```

## Ce que le patch ajoute

- Dashboard admin `/admin`
- Création de cours `/admin/courses/new`
- Planning admin `/admin/schedule`
- Gestion des rôles membres `/admin/members`
- Endpoint backend `PATCH /members/{member_id}/role`
- Theme dark premium vert/or inspiré plateforme pédagogique type Submeta

## Important

Ton membre doit avoir `role='admin'` en DB pour voir l'onglet Admin.
